import React from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import { X, Download, Printer, Mail, Phone, MapPin, Globe, Linkedin, Github } from 'lucide-react';

interface ResumeModalProps {
  isOpen: boolean;
  onClose: () => void;
  recruiterData?: {
    name: string;
    company: string;
    role: string;
  } | null;
}

export const ResumeModal: React.FC<ResumeModalProps> = ({ isOpen, onClose, recruiterData }) => {
  const handlePrint = () => {
    window.print();
  };

  const handleDownload = () => {
    // We can trigger browser print to PDF or generate a download
    // Since we want standard pdf, printing to pdf is the most reliable and premium way.
    window.print();
  };

  return (
    <AnimatePresence>
      {isOpen && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/80 backdrop-blur-md overflow-y-auto">
          {/* Backdrop */}
          <motion.div
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            exit={{ opacity: 0 }}
            className="absolute inset-0"
            onClick={onClose}
          />

          {/* Modal Content */}
          <motion.div
            initial={{ opacity: 0, scale: 0.95, y: 20 }}
            animate={{ opacity: 1, scale: 1, y: 0 }}
            exit={{ opacity: 0, scale: 0.95, y: 20 }}
            transition={{ duration: 0.4, ease: 'easeOut' }}
            className="relative w-full max-w-4xl bg-[#0d0d0d] border border-gold/20 rounded-2xl shadow-2xl overflow-hidden z-10 my-8"
          >
            {/* Header controls (Hidden on print) */}
            <div className="flex items-center justify-between px-6 py-4 border-b border-white/10 bg-black/40 print:hidden">
              <div className="flex items-center gap-2">
                <span className="w-3 h-3 rounded-full bg-red-500" />
                <span className="w-3 h-3 rounded-full bg-yellow-500" />
                <span className="w-3 h-3 rounded-full bg-green-500" />
                <span className="ml-2 text-sm text-neutral-400 font-mono">dhruv_shah_resume.pdf</span>
              </div>
              <div className="flex items-center gap-4">
                <button
                  onClick={handlePrint}
                  className="flex items-center gap-2 px-4 py-1.5 rounded-full bg-neutral-900 border border-white/10 hover:border-gold/50 text-neutral-300 hover:text-gold text-xs font-medium transition-all"
                >
                  <Printer size={14} />
                  Print / Save PDF
                </button>
                <button
                  onClick={onClose}
                  className="p-1.5 rounded-full bg-neutral-900 border border-white/10 hover:border-red-500/50 text-neutral-400 hover:text-red-500 transition-all"
                >
                  <X size={16} />
                </button>
              </div>
            </div>

            {/* Resume Sheet */}
            <div className="p-8 md:p-12 max-h-[80vh] overflow-y-auto bg-white text-neutral-900 print:max-h-full print:p-0 print:overflow-visible font-sans">
              
              {/* Recruiter Custom Header (Print only if recruiterData is present) */}
              {recruiterData && (
                <div className="mb-6 p-4 bg-amber-50 border border-amber-200 rounded-lg text-xs text-amber-800 print:hidden">
                  <p className="font-semibold text-sm mb-1">Tailored for {recruiterData.company}</p>
                  <p>Hi {recruiterData.name}, this resume is customized to match your open <strong>{recruiterData.role}</strong> position at <strong>{recruiterData.company}</strong>. Click "Print / Save PDF" to export.</p>
                </div>
              )}

              {/* Main Header */}
              <div className="border-b-2 border-amber-600 pb-6 mb-6">
                <div className="flex flex-col md:flex-row justify-between items-start md:items-end gap-4">
                  <div>
                    <h1 className="text-4xl font-extrabold tracking-tight text-neutral-900 font-serif">
                      Dhruv Shah
                    </h1>
                    <p className="text-lg font-medium text-amber-700 tracking-wide mt-1">
                      {recruiterData?.role || 'Full Stack Developer'}
                    </p>
                  </div>
                  <div className="grid grid-cols-2 gap-x-6 gap-y-1.5 text-xs text-neutral-600 font-mono">
                    <span className="flex items-center gap-1.5">
                      <Mail size={12} className="text-amber-700" />
                      dhruvshah@example.com
                    </span>
                    <span className="flex items-center gap-1.5">
                      <Phone size={12} className="text-amber-700" />
                      +1 (555) 019-2831
                    </span>
                    <span className="flex items-center gap-1.5">
                      <MapPin size={12} className="text-amber-700" />
                      San Francisco, CA
                    </span>
                    <span className="flex items-center gap-1.5">
                      <Globe size={12} className="text-amber-700" />
                      dhruvshah.dev
                    </span>
                    <span className="flex items-center gap-1.5">
                      <Github size={12} className="text-amber-700" />
                      github.com/dhruvshah
                    </span>
                    <span className="flex items-center gap-1.5">
                      <Linkedin size={12} className="text-amber-700" />
                      linkedin.com/in/dhruvshah
                    </span>
                  </div>
                </div>
              </div>

              {/* Summary */}
              <div className="mb-6">
                <h2 className="text-sm font-bold tracking-wider text-amber-800 uppercase mb-2 font-serif border-b border-neutral-200 pb-1">
                  Professional Summary
                </h2>
                <p className="text-sm text-neutral-700 leading-relaxed">
                  High-achieving Full Stack Developer with 4+ years of academic and project experience building premium, ultra-scalable web applications. University Gold Medalist (CGPA: 9.56/10.0) with deep expertise in React, Next.js, TypeScript, Node.js, and cloud architecture (AWS). Proven track record of winning national hackathons and developing high-performance architectures, specializing in creating flawless user experiences coupled with robust backend infrastructures.
                </p>
              </div>

              {/* Technical Skills */}
              <div className="mb-6">
                <h2 className="text-sm font-bold tracking-wider text-amber-800 uppercase mb-2 font-serif border-b border-neutral-200 pb-1">
                  Technical Expertise
                </h2>
                <div className="grid grid-cols-1 md:grid-cols-2 gap-x-8 gap-y-2 text-sm text-neutral-700">
                  <div>
                    <span className="font-semibold text-neutral-900">Languages & Frontend:</span> TypeScript, JavaScript, Python, Go, SQL, HTML5/CSS3, React, Next.js, Redux, Tailwind CSS, Framer Motion
                  </div>
                  <div>
                    <span className="font-semibold text-neutral-900">Backend & Databases:</span> Node.js, Express, NestJS, FastAPI, REST, GraphQL, PostgreSQL, MongoDB, Redis, MySQL, Prisma ORM
                  </div>
                  <div>
                    <span className="font-semibold text-neutral-900">DevOps & Cloud:</span> AWS (S3, EC2, Lambda, DynamoDB), Docker, Git, CI/CD (GitHub Actions), Vercel, Supabase, Linux
                  </div>
                  <div>
                    <span className="font-semibold text-neutral-900">Methodologies:</span> Agile/Scrum, System Design, RESTful API Design, Microservices, CI/CD, Unit/Integration Testing
                  </div>
                </div>
              </div>

              {/* Experience / Key Projects */}
              <div className="mb-6">
                <h2 className="text-sm font-bold tracking-wider text-amber-800 uppercase mb-3 font-serif border-b border-neutral-200 pb-1">
                  Key Projects & Experience
                </h2>

                <div className="space-y-4">
                  {/* Project 1 */}
                  <div>
                    <div className="flex justify-between items-baseline">
                      <h3 className="text-sm font-bold text-neutral-900">
                        Aura — Premium Wealth Management Platform
                      </h3>
                      <span className="text-xs font-mono text-neutral-500">Next.js, FastAPI, PostgreSQL, AWS</span>
                    </div>
                    <p className="text-xs italic text-amber-700 mb-1">Lead Developer | Personal Project</p>
                    <ul className="list-disc list-inside text-xs text-neutral-700 space-y-1 pl-1">
                      <li>Designed and implemented a premium financial dashboard handling simulated real-time analytics with interactive SVG charting.</li>
                      <li>Architected a predictive portfolio rebalancing algorithm in FastAPI, reducing latency by 45% using Redis caching.</li>
                      <li>Integrated secure OAuth2 authentication and built containerized microservices deployed on AWS EC2.</li>
                    </ul>
                  </div>

                  {/* Project 2 */}
                  <div>
                    <div className="flex justify-between items-baseline">
                      <h3 className="text-sm font-bold text-neutral-900">
                        Chronos — Real-time Collaborative IDE
                      </h3>
                      <span className="text-xs font-mono text-neutral-500">React, WebSockets, Node.js, Docker</span>
                    </div>
                    <p className="text-xs italic text-amber-700 mb-1">Full Stack Engineer | Personal Project</p>
                    <ul className="list-disc list-inside text-xs text-neutral-700 space-y-1 pl-1">
                      <li>Developed a high-performance, real-time shared code editor utilizing Yjs CRDTs and WebSockets for conflict-free editing.</li>
                      <li>Created a secure, sandboxed code execution environment using Docker containers to safely compile and run user-submitted code in 8+ languages.</li>
                      <li>Implemented customizable editor themes, keyboard shortcuts, and integrated multi-user audio rooms.</li>
                    </ul>
                  </div>

                  {/* Project 3 */}
                  <div>
                    <div className="flex justify-between items-baseline">
                      <h3 className="text-sm font-bold text-neutral-900">
                        Vortex — AI-Powered Video Search Engine
                      </h3>
                      <span className="text-xs font-mono text-neutral-500">Python, PyTorch, Qdrant Vector DB, React</span>
                    </div>
                    <p className="text-xs italic text-amber-700 mb-1">AI Engineer | Research Project</p>
                    <ul className="list-disc list-inside text-xs text-neutral-700 space-y-1 pl-1">
                      <li>Built a semantic search engine processing video files to perform precise context-based frame and dialog search.</li>
                      <li>Leveraged OpenAI CLIP model for frame vector embeddings and Whisper for audio transcriptions, indexed in Qdrant Vector Database.</li>
                      <li>Optimized vector search queries to deliver results under 150ms over a database of 500+ hours of video material.</li>
                    </ul>
                  </div>
                </div>
              </div>

              {/* Education */}
              <div className="mb-6">
                <h2 className="text-sm font-bold tracking-wider text-amber-800 uppercase mb-3 font-serif border-b border-neutral-200 pb-1">
                  Education
                </h2>
                <div className="flex justify-between items-start">
                  <div>
                    <h3 className="text-sm font-bold text-neutral-900">
                      Bachelor of Technology in Computer Science & Engineering
                    </h3>
                    <p className="text-xs text-neutral-700">Prestige Institute of Technology & Science</p>
                    <p className="text-xs text-neutral-500 italic mt-0.5">
                      Honors: University Gold Medalist (Rank 1 out of 450+ students), Dean's List (All Semesters)
                    </p>
                  </div>
                  <div className="text-right">
                    <span className="text-xs font-mono text-neutral-500 block">2021 — 2025</span>
                    <span className="inline-block bg-amber-100 text-amber-800 text-[10px] font-bold px-2 py-0.5 rounded mt-1">
                      CGPA: 9.56 / 10.0
                    </span>
                  </div>
                </div>
              </div>

              {/* Achievements & Certifications */}
              <div>
                <h2 className="text-sm font-bold tracking-wider text-amber-800 uppercase mb-3 font-serif border-b border-neutral-200 pb-1">
                  Honors, Awards & Certifications
                </h2>
                <ul className="list-disc list-inside text-xs text-neutral-700 space-y-1.5 pl-1">
                  <li>
                    <strong className="text-neutral-900">Winner (First Prize)</strong> — Smart India Hackathon (National Level): Developed an AI-driven smart crop-yield and irrigation recommendation platform for 10M+ farmers.
                  </li>
                  <li>
                    <strong className="text-neutral-900">Runner-Up</strong> — HackOut Hackathon: Engineered a decentralized credential verification system on blockchain within 36 hours.
                  </li>
                  <li>
                    <strong className="text-neutral-900">AWS Certified Developer – Associate</strong> — Amazon Web Services (Validation ID: AWS-ASA-9921)
                  </li>
                  <li>
                    <strong className="text-neutral-900">1st Rank in Department-wide Coding Olympiad</strong> — Outperformed 800+ participants in a 5-hour algorithmic coding competition.
                  </li>
                </ul>
              </div>

            </div>
          </motion.div>
        </div>
      )}
    </AnimatePresence>
  );
};
