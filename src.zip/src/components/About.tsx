import React from 'react';
import { motion } from 'framer-motion';
import { GraduationCap, Briefcase, Code, Award, ChevronRight, Sparkles } from 'lucide-react';

interface AboutProps {
  onOpenResume: () => void;
  recruiterData: { name: string; company: string; role: string } | null;
}

export const About: React.FC<AboutProps> = ({ onOpenResume, recruiterData }) => {
  const stats = [
    {
      label: 'CGPA',
      value: '9.56 / 10.0',
      description: 'University Gold Medalist (Rank 1)',
      icon: <GraduationCap className="text-gold" size={20} />,
    },
    {
      label: 'Projects',
      value: '12+ Completed',
      description: 'Production-ready full stack apps',
      icon: <Code className="text-gold" size={20} />,
    },
    {
      label: 'Technologies',
      value: '25+ Mastered',
      description: 'Modern high-performance stacks',
      icon: <Briefcase className="text-gold" size={20} />,
    },
    {
      label: 'Achievements',
      value: 'National Winner',
      description: 'Smart India Hackathon & more',
      icon: <Award className="text-gold" size={20} />,
    },
  ];

  return (
    <section id="about" className="py-24 relative overflow-hidden">
      {/* Background Lights */}
      <div className="absolute top-1/2 left-0 w-[250px] h-[250px] bg-gold-dark/5 rounded-full blur-[100px] pointer-events-none" />

      <div className="max-w-7xl mx-auto px-6 relative z-10">
        
        {/* Section Header */}
        <div className="mb-16">
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: true }}
            transition={{ duration: 0.6 }}
            className="inline-flex items-center gap-2 px-3 py-1 rounded-full bg-gold/10 border border-gold/30 text-gold text-xs font-mono tracking-wider uppercase mb-4"
          >
            <Sparkles size={12} />
            The Artisan
          </motion.div>
          <motion.h2
            initial={{ opacity: 0, y: 20 }}
            whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: true }}
            transition={{ duration: 0.6, delay: 0.1 }}
            className="text-3xl md:text-5xl font-bold tracking-tight text-white font-serif"
          >
            Behind the Craft: <span className="gold-text-gradient">Dhruv Shah</span>
          </motion.h2>
        </div>

        {/* Two-Column Layout */}
        <div className="grid grid-cols-1 lg:grid-cols-12 gap-12 items-start mb-16">
          
          {/* Left Column: Story */}
          <motion.div
            initial={{ opacity: 0, y: 30 }}
            whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: true }}
            transition={{ duration: 0.8 }}
            className="lg:col-span-7 space-y-6"
          >
            <h3 className="text-xl md:text-2xl font-semibold text-white font-serif">
              {recruiterData ? (
                <>Engineering Software that Drives <span className="text-gold">{recruiterData.company}</span>'s Innovations</>
              ) : (
                <>Bridging the Gap Between <span className="text-gold">Sleek Interface</span> and <span className="text-gold">Architectural Integrity</span></>
              )}
            </h3>
            
            <p className="text-neutral-400 text-sm md:text-base leading-relaxed">
              I am a final-year BCA student who treats software development as a fine craft. Over the past 2 - 3 years, I have maintained an outstanding academic record,  while dedicating thousands of hours to coding, system design, and building production-ready personal platforms.
            </p>

            <p className="text-neutral-400 text-sm md:text-base leading-relaxed">
              My philosophy aligns with Apple's standard of computing: every line of code should be clean, every interface should feel fluid, and the underlying architecture must be bulletproof. I don't just build features; I architect solutions that scale, optimize performance down to the millisecond.
            </p>

            <p className="text-neutral-400 text-sm md:text-base leading-relaxed">
              I strive to push the boundaries of what is possible in web engineering.
            </p>

            {/* Quick List */}
            <div className="grid grid-cols-1 md:grid-cols-2 gap-4 pt-4">
              <div className="flex items-center gap-2 text-sm text-neutral-300">
                <ChevronRight size={16} className="text-gold" />
                <span>Focus: Full Stack Engineering</span>
              </div>
              <div className="flex items-center gap-2 text-sm text-neutral-300">
                <ChevronRight size={16} className="text-gold" />
                <span>Cloud: AWS certified associate</span>
              </div>
              <div className="flex items-center gap-2 text-sm text-neutral-300">
                <ChevronRight size={16} className="text-gold" />
                <span>Methodologies: Agile & Microservices</span>
              </div>
              <div className="flex items-center gap-2 text-sm text-neutral-300">
                <ChevronRight size={16} className="text-gold" />
                <span>R&D: AI Vector Databases & Web3</span>
              </div>
            </div>

            <div className="pt-6">
              <button
                onClick={onOpenResume}
                className="inline-flex items-center gap-2 px-6 py-3 rounded-full bg-gold/10 hover:bg-gold/20 border border-gold/30 hover:border-gold text-gold hover:text-white text-xs font-mono uppercase tracking-wider transition-all cursor-pointer"
              >
                Explore Interactive Resume
              </button>
            </div>
          </motion.div>

          {/* Right Column: Grid of Stats */}
          <div className="lg:col-span-5 grid grid-cols-1 sm:grid-cols-2 gap-6 w-full">
            {stats.map((stat, idx) => (
              <motion.div
                key={stat.label}
                initial={{ opacity: 0, scale: 0.9, y: 20 }}
                whileInView={{ opacity: 1, scale: 1, y: 0 }}
                viewport={{ once: true }}
                transition={{ duration: 0.6, delay: idx * 0.1 }}
                whileHover={{ y: -5, borderColor: 'rgba(212, 175, 55, 0.3)' }}
                className="glass-card p-6 rounded-2xl border border-gold/10 flex flex-col justify-between h-44 shadow-lg transition-all duration-300"
              >
                <div className="flex justify-between items-start">
                  <div className="p-2.5 rounded-xl bg-gold/5 border border-gold/20">
                    {stat.icon}
                  </div>
                  <span className="text-[10px] font-mono text-neutral-500 uppercase tracking-widest">{stat.label}</span>
                </div>
                <div className="mt-4">
                  <h4 className="text-2xl md:text-3xl font-bold text-white font-serif tracking-tight">
                    {stat.value}
                  </h4>
                  <p className="text-[11px] text-neutral-400 font-mono mt-1 leading-snug">
                    {stat.description}
                  </p>
                </div>
              </motion.div>
            ))}
          </div>

        </div>

      </div>
    </section>
  );
};
