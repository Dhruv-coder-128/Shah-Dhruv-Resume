import React from 'react';
import { motion, Variants } from 'framer-motion';
import { ArrowDown, FileText, Briefcase, Sparkles, Code, Cpu, Database } from 'lucide-react';

interface HeroProps {
  onOpenResume: () => void;
  recruiterData: { name: string; company: string; role: string } | null;
}

export const Hero: React.FC<HeroProps> = ({ onOpenResume, recruiterData }) => {
  const containerVariants: Variants = {
    hidden: { opacity: 0 },
    visible: {
      opacity: 1,
      transition: {
        staggerChildren: 0.15,
        delayChildren: 0.2,
      },
    },
  };

  const itemVariants: Variants = {
    hidden: { opacity: 0, y: 30 },
    visible: {
      opacity: 1,
      y: 0,
      transition: {
        duration: 0.8,
        ease: [0.16, 1, 0.3, 1], // Custom cubic-bezier for Apple-like smoothness
      },
    },
  };

  return (
    <section id="hero" className="relative min-h-screen flex items-center justify-center pt-24 overflow-hidden">
      {/* Premium Ambient Lights */}
      <div className="absolute top-1/4 left-1/4 w-[300px] h-[300px] bg-gold/10 rounded-full blur-[120px] pointer-events-none" />
      <div className="absolute bottom-1/4 right-1/4 w-[400px] h-[400px] bg-gold-dark/5 rounded-full blur-[150px] pointer-events-none" />

      <div className="max-w-7xl mx-auto px-6 w-full grid grid-cols-1 lg:grid-cols-12 gap-12 items-center relative z-10 py-12">

        {/* Left Side: Copy / Typography */}
        <motion.div
          variants={containerVariants}
          initial="hidden"
          animate="visible"
          className="lg:col-span-7 text-left flex flex-col justify-center"
        >
          {/* Badge */}
          <motion.div variants={itemVariants} className="mb-6">
            <span className="inline-flex items-center gap-2 px-3.5 py-1.5 rounded-full bg-neutral-900/80 border border-gold/20 text-gold text-xs font-mono tracking-widest uppercase shadow-lg shadow-gold/5">
              <Sparkles size={12} className="animate-pulse" />
              {recruiterData ? (
                <span>Exclusive Portfolio for {recruiterData.company}</span>
              ) : (
                <span>University Gold Medalist • Full Stack Engineer</span>
              )}
            </span>
          </motion.div>

          {/* Main Title */}
          <motion.div variants={itemVariants} className="space-y-1 mb-6">
            <h1 className="text-5xl md:text-7xl lg:text-8xl font-extrabold tracking-tight text-white font-serif leading-none">
              Dhruv Shah
            </h1>
            <h2 className="text-2xl md:text-4xl lg:text-5xl font-bold tracking-tight text-neutral-400 font-serif">
              {recruiterData ? (
                <>Your Next <span className="gold-text-gradient">{recruiterData.role}</span></>
              ) : (
                <>Crafting <span className="gold-text-gradient">Digital Masterpieces</span></>
              )}
            </h2>
          </motion.div>

          {/* Subtitle / Tagline */}
          <motion.p
            variants={itemVariants}
            className="text-neutral-400 max-w-xl text-sm md:text-base leading-relaxed mb-10 font-sans"
          >
            {recruiterData ? (
              `Hi ${recruiterData.name}, I am a high-performance Full Stack Developer specializing in building elegant user experiences coupled with highly scalable backends. I've built this tailored space to demonstrate how my technical stack perfectly aligns with ${recruiterData.company}'s engineering standards.`
            ) : (
              "A premium Full Stack Engineer specializing in building ultra-performance web architectures. Blending award-winning aesthetics with secure, highly-scalable backend systems. Focused on engineering excellence, microsecond optimizations, and pristine design."
            )}
          </motion.p>

          {/* CTA Buttons */}
          <motion.div variants={itemVariants} className="flex flex-wrap gap-4 items-center">
            <a
              href="#projects"
              className="px-8 py-4 rounded-full bg-gradient-to-r from-gold-dark via-gold to-gold-light text-black font-semibold text-xs font-mono uppercase tracking-widest hover:scale-105 transition-all shadow-lg shadow-gold/15 hover:shadow-gold/30 cursor-pointer"
            >
              View My Work
            </a>
            <button
              onClick={onOpenResume}
              className="flex items-center gap-2 px-8 py-4 rounded-full border border-gold/30 hover:border-gold bg-black/40 hover:bg-gold/5 text-gold hover:text-white text-xs font-mono uppercase tracking-widest transition-all cursor-pointer"
            >
              <FileText size={14} />
              View Resume
            </button>
            <a
              href="#recruiter"
              className="flex items-center gap-1.5 text-xs font-mono text-neutral-500 hover:text-gold tracking-wider uppercase transition-colors ml-2 py-2"
            >
              <Briefcase size={12} />
              Recruiter Hub
            </a>
          </motion.div>
        </motion.div>

        {/* Right Side: Luxury Interactive Visual Element (Apple-style Keynote Abstract representation) */}
        <motion.div
          initial={{ opacity: 0, scale: 0.8 }}
          animate={{ opacity: 1, scale: 1 }}
          transition={{ duration: 1, delay: 0.4 }}
          className="lg:col-span-5 flex justify-center items-center relative"
        >
          {/* Glow Effect */}
          <div className="absolute w-[350px] h-[350px] bg-gold/10 rounded-full blur-3xl" />

          {/* Profile Image */}
          <div className="relative">
            <div className="absolute inset-0 flex items-center justify-center -z-10" />

            <img
              src="/dhruv.jpeg"
              alt="Dhruv Shah"
              className="
      w-[450px]
      h-[450px]
      rounded-full
      border
      border-gold/20
    "
            />
          </div>
        </motion.div>
      </div>

      {/* Down Arrow / Scroll Indicator */}
      <div className="absolute bottom-10 left-1/2 -translate-x-1/2 z-10 flex flex-col items-center gap-1.5 cursor-pointer">
        <span className="text-[10px] font-mono tracking-widest text-neutral-500 uppercase">Scroll to Explore</span>
        <motion.div
          animate={{ y: [0, 6, 0] }}
          transition={{ duration: 1.5, repeat: Infinity, ease: 'easeInOut' }}
          className="text-gold"
        >
          <ArrowDown size={14} />
        </motion.div>
      </div>
    </section>
  );
};
