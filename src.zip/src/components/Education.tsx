import React from 'react';
import { motion } from 'framer-motion';
import { GraduationCap, Award, Calendar, BookOpen, Sparkles } from 'lucide-react';

interface EducationItem {
  degree: string;
  institution: string;
  duration: string;
  score: string;
  honors: string[];
  coursework: string[];
}

export const Education: React.FC = () => {
  const educationList: EducationItem[] = [
    {
      degree: 'Bachelor of Computer Application (BCA)',
      institution: 'Noble University',
      duration: '2024-2027',
      score: 'CGPA: 8.30 / 10.0 (sem 4)',
      honors: [
        'University First (Rank 1 out of 450+ students)',
        'Dean’s List for Academic Excellence (All semesters)',
      ],
      coursework: [
        'Data Structures & Algorithms',
        'System Design & Distributed Systems',
        'Database Management Systems (RDBMS & NoSQL)',
        'Object-Oriented Programming (OOP) & Design Patterns',
        'Computer Networks & Cryptography',
        'Operating Systems & Cloud Computing',
        'Application using Android',
        'Advance Java',

      ]
    },
    {
      degree: 'Class 12(Grade XII)',
      institution: 'Eklavya Public School',
      duration: '2023 — 2024',
      score: 'Score: 97.4%',
      honors: [
        'Ranked in Top 5 of our school',

      ],
      coursework: [
        'Basics of Computer',
        'Mathematics (Calculus, Algebra)',
        'English',
        'Computer Science (C++, OOP basics)'
      ]
    },
    {
      degree: 'Class 10(Grade X)',
      institution: 'Noble High School',
      duration: '2021 — 2022',
      score: 'Score: 97.4%',
      honors: [
        'Ranked in Top 5 of our school',

      ],
      coursework: [
        'Basics of Computer',
        'Mathematics (Calculus, Algebra)',
        'English',
        'Computer Science (C++, OOP basics)'
      ]
    }
  ];

  return (
    <section id="education" className="py-24 relative overflow-hidden bg-black">
      {/* Background ambient light */}
      <div className="absolute bottom-1/4 right-0 w-[300px] h-[300px] bg-gold/5 rounded-full blur-[120px] pointer-events-none" />

      <div className="max-w-7xl mx-auto px-6 relative z-10">
        
        {/* Section Header */}
        <div className="text-center mb-16">
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: true }}
            transition={{ duration: 0.6 }}
            className="inline-flex items-center gap-2 px-3 py-1 rounded-full bg-gold/10 border border-gold/30 text-gold text-xs font-mono tracking-wider uppercase mb-4"
          >
            <GraduationCap size={12} />
            Academic Path
          </motion.div>
          <motion.h2
            initial={{ opacity: 0, y: 20 }}
            whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: true }}
            transition={{ duration: 0.6, delay: 0.1 }}
            className="text-3xl md:text-5xl font-bold tracking-tight text-white font-serif mb-4"
          >
            Education <span className="gold-text-gradient">Timeline</span>
          </motion.h2>
          <motion.p
            initial={{ opacity: 0, y: 20 }}
            whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: true }}
            transition={{ duration: 0.6, delay: 0.2 }}
            className="text-neutral-400 max-w-2xl mx-auto text-sm md:text-base"
          >
            A vertical chronicle detailing academic rigor, honors, and specialized computer science curricula.
          </motion.p>
        </div>

        {/* Vertical Timeline */}
        <div className="relative max-w-4xl mx-auto pl-6 md:pl-0">
          
          {/* Vertical Center Line (Desktop) */}
          <div className="absolute left-6 md:left-1/2 top-0 bottom-0 w-[1px] bg-gold/20 -translate-x-1/2 hidden md:block" />
          {/* Vertical Left Line (Mobile) */}
          <div className="absolute left-6 top-0 bottom-0 w-[1px] bg-gold/20 -translate-x-1/2 md:hidden" />

          <div className="space-y-16">
            {educationList.map((item, idx) => (
              <div key={item.degree} className={`relative flex flex-col md:flex-row items-stretch ${idx % 2 === 0 ? 'md:flex-row-reverse' : ''}`}>
                
                {/* Timeline Node Icon */}
                <div className="absolute left-6 md:left-1/2 top-0 -translate-x-1/2 -translate-y-1/3 z-20 w-12 h-12 rounded-full bg-black border border-gold/40 flex items-center justify-center text-gold shadow-lg shadow-gold/5">
                  <GraduationCap size={18} />
                </div>

                {/* Blank space on opposite column (Desktop only) */}
                <div className="w-full md:w-1/2 hidden md:block" />

                {/* Content Card */}
                <motion.div
                  initial={{ opacity: 0, x: idx % 2 === 0 ? 30 : -30 }}
                  whileInView={{ opacity: 1, x: 0 }}
                  viewport={{ once: true }}
                  transition={{ duration: 0.8, ease: 'easeOut' }}
                  className="w-full md:w-1/2 pl-12 md:pl-0 md:px-8"
                >
                  <div className="glass-card rounded-2xl border border-gold/10 p-6 md:p-8 hover:border-gold/30 transition-all duration-300 relative group">
                    <div className="absolute inset-0 bg-gradient-to-br from-gold/5 via-transparent to-transparent opacity-50 rounded-2xl" />
                    
                    {/* Header */}
                    <div className="flex flex-wrap justify-between items-baseline gap-2 mb-4 relative z-10">
                      <span className="inline-flex items-center gap-1 text-[10px] font-mono text-gold bg-gold/5 border border-gold/20 px-2 py-0.5 rounded">
                        <Calendar size={10} />
                        {item.duration}
                      </span>
                      <span className="text-xs font-mono text-emerald-400 bg-emerald-500/10 border border-emerald-500/20 px-2.5 py-0.5 rounded font-bold">
                        {item.score}
                      </span>
                    </div>

                    <h3 className="text-lg font-bold text-white font-serif tracking-tight group-hover:text-gold transition-colors relative z-10">
                      {item.degree}
                    </h3>
                    
                    <p className="text-neutral-400 text-xs font-mono italic mt-1 mb-4 relative z-10">
                      {item.institution}
                    </p>

                    {/* Honors / Achievements list */}
                    <div className="space-y-2 mb-6 relative z-10">
                      <h4 className="text-[10px] font-mono text-gold uppercase tracking-wider flex items-center gap-1.5">
                        <Award size={12} />
                        Academic Honors
                      </h4>
                      <ul className="space-y-1.5 pl-2 border-l border-gold/20">
                        {item.honors.map((h, i) => (
                          <li key={i} className="text-xs text-neutral-300 leading-relaxed pl-1.5 relative">
                            <span className="absolute left-0 top-2 w-1 h-1 rounded-full bg-gold/50" />
                            {h}
                          </li>
                        ))}
                      </ul>
                    </div>

                    {/* Core Coursework Tags */}
                    <div className="space-y-2 relative z-10">
                      <h4 className="text-[10px] font-mono text-gold uppercase tracking-wider flex items-center gap-1.5">
                        <BookOpen size={12} />
                        Core Coursework
                      </h4>
                      <div className="flex flex-wrap gap-1.5">
                        {item.coursework.map(c => (
                          <span key={c} className="px-2 py-0.5 rounded bg-black/60 border border-white/5 text-neutral-400 text-[9px] font-mono hover:border-gold/30 transition-colors">
                            {c}
                          </span>
                        ))}
                      </div>
                    </div>

                  </div>
                </motion.div>

              </div>
            ))}
          </div>

        </div>

      </div>
    </section>
  );
};
