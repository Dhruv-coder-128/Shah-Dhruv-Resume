import React from 'react';
import { motion } from 'framer-motion';
import { Award, Trophy, Star, ShieldCheck, Calendar, Sparkles } from 'lucide-react';

interface Achievement {
  title: string;
  subtitle: string;
  date: string;
  category: string;
  metrics: string;
  description: string;
  icon: React.ReactNode;
}

export const Achievements: React.FC = () => {
  const achievements: Achievement[] = [
    {
      title: 'University Rank 1 & Gold Medalist',
      subtitle: 'Prestige Institute of Technology & Science',
      date: 'June 2025',
      category: 'Academics',
      metrics: 'Rank 1 / 450+ Students',
      description: 'Awarded the University Gold Medal for maintaining the highest cumulative GPA (9.56/10.0) across 8 semesters in the Computer Science & Engineering department.',
      icon: <Trophy className="text-gold" size={24} />,
    },
    {
      title: 'Winner (1st Prize) — Smart India Hackathon',
      subtitle: 'Ministry of Education, Govt. of India',
      date: 'December 2023',
      category: 'Hackathons',
      metrics: 'National Level Champion',
      description: 'Led a team of 6 engineers to develop an AI-driven smart crop yield recommendation and automated irrigation management platform. Competed against 150+ teams in the final round.',
      icon: <Award className="text-gold" size={24} />,
    },
    {
      title: 'Runner-Up — HackOut Hackathon',
      subtitle: 'National Level 36-Hour Hackathon',
      date: 'October 2022',
      category: 'Hackathons',
      metrics: '2nd Place out of 200+ Teams',
      description: 'Engineered a decentralized academic credential verification system on the Ethereum blockchain under 36 hours. Designed the gas-optimized smart contracts and integrated Web3 wallets.',
      icon: <Star className="text-gold" size={24} />,
    },
    {
      title: 'AWS Certified Developer – Associate',
      subtitle: 'Amazon Web Services (AWS)',
      date: 'March 2024',
      category: 'Certifications',
      metrics: 'Validation ID: AWS-ASA-9921',
      description: 'Demonstrated proficiency in developing, deploying, and securing applications using AWS cloud core services (EC2, S3, Lambda, DynamoDB, VPC, IAM).',
      icon: <ShieldCheck className="text-gold" size={24} />,
    },
  ];

  return (
    <section id="achievements" className="py-24 relative overflow-hidden bg-neutral-950/20">
      {/* Background radial glow */}
      <div className="absolute top-1/2 left-1/4 w-[400px] h-[400px] bg-gold-dark/5 rounded-full blur-[150px] pointer-events-none" />

      <div className="max-w-7xl mx-auto px-6 relative z-10">
        
        {/* Section Header */}
        <div className="text-center mb-16">
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: true }}
            transition={{ duration: 0.6 }}
            className="inline-flex items-center gap-2 px-3 py-1 rounded-full bg-gold/10 border border-gold/30 text-gold text-xs font-mono tracking-wider uppercase mb-4"
          >
            <Trophy size={12} />
            Honors & Ranks
          </motion.div>
          <motion.h2
            initial={{ opacity: 0, y: 20 }}
            whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: true }}
            transition={{ duration: 0.6, delay: 0.1 }}
            className="text-3xl md:text-5xl font-bold tracking-tight text-white font-serif mb-4"
          >
            Milestones of <span className="gold-text-gradient">Excellence</span>
          </motion.h2>
          <motion.p
            initial={{ opacity: 0, y: 20 }}
            whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: true }}
            transition={{ duration: 0.6, delay: 0.2 }}
            className="text-neutral-400 max-w-2xl mx-auto text-sm md:text-base"
          >
            A timeline of academic honors, national-level hackathon championships, and professional industry certifications.
          </motion.p>
        </div>

        {/* Timeline Grid */}
        <div className="space-y-8 max-w-4xl mx-auto">
          {achievements.map((ach, idx) => (
            <motion.div
              key={ach.title}
              initial={{ opacity: 0, x: idx % 2 === 0 ? -35 : 30 }}
              whileInView={{ opacity: 1, x: 0 }}
              viewport={{ once: true }}
              transition={{ duration: 0.8, ease: 'easeOut' }}
              className="glass-card rounded-2xl border border-gold/10 p-6 md:p-8 flex flex-col md:flex-row gap-6 hover:border-gold/30 hover:bg-neutral-900/40 transition-all duration-300 group"
            >
              {/* Icon Side */}
              <div className="flex md:flex-col items-center justify-between md:justify-start gap-4 shrink-0">
                <div className="w-14 h-14 rounded-2xl bg-gold/5 border border-gold/20 flex items-center justify-center text-gold group-hover:scale-110 transition-transform duration-300 shadow-md">
                  {ach.icon}
                </div>
                <div className="text-right md:text-center mt-1">
                  <span className="inline-flex items-center gap-1 text-[10px] font-mono text-neutral-500 uppercase tracking-widest">
                    <Calendar size={10} />
                    {ach.date}
                  </span>
                </div>
              </div>

              {/* Description Side */}
              <div className="flex-grow space-y-3">
                <div className="flex flex-wrap justify-between items-baseline gap-x-4 gap-y-1">
                  <span className="text-[10px] font-mono text-gold bg-gold/10 border border-gold/20 px-2 py-0.5 rounded uppercase tracking-wider">
                    {ach.category}
                  </span>
                  <span className="text-xs font-mono text-gold-light font-bold">
                    {ach.metrics}
                  </span>
                </div>

                <h3 className="text-xl font-bold text-white font-serif tracking-tight group-hover:text-gold transition-colors">
                  {ach.title}
                </h3>
                
                <p className="text-xs md:text-sm text-neutral-400 font-mono italic">
                  {ach.subtitle}
                </p>

                <p className="text-xs md:text-sm text-neutral-300 leading-relaxed font-sans pt-1">
                  {ach.description}
                </p>
              </div>
            </motion.div>
          ))}
        </div>

      </div>
    </section>
  );
};
